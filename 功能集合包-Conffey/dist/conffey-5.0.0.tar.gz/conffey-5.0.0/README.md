﻿# Conffey #

###### Function:

A library that encapsulates various functions of Python.

###### Version:

*v5.0.0*

###### Download:

Open `Cmd` (or `Bash`),

Enter *`pip install conffey`* .

**Fork** and **Star** [me](https://github.com/super-took/Conffey) on Github !